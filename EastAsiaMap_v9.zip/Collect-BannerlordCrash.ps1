# Optional collector for a small set of Bannerlord text logs.
# This does not collect dumps, saves, environment variables, or credential files.
[CmdletBinding()]
param(
    [string]$LogDirectory,
    [string]$OutputPath = (Join-Path (Get-Location).Path ("Bannerlord-logs-{0}.zip" -f (Get-Date -Format 'yyyyMMdd-HHmmss')))
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($LogDirectory)) {
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramData)) {
        $candidateDirectory = Join-Path $env:ProgramData 'Mount and Blade II Bannerlord\logs'
        if (Test-Path -LiteralPath $candidateDirectory -PathType Container) {
            $LogDirectory = $candidateDirectory
        }
    }
}

if ([string]::IsNullOrWhiteSpace($LogDirectory) -or
    -not (Test-Path -LiteralPath $LogDirectory -PathType Container)) {
    throw 'Bannerlord log directory was not found. Locate the folder containing rgl_log*.txt files, then run this script with -LogDirectory <that-folder>. No files were collected.'
}

$resolvedDirectory = (Resolve-Path -LiteralPath $LogDirectory).ProviderPath
$maxFileBytes = 20MB
$matchingFiles = @(Get-ChildItem -LiteralPath $resolvedDirectory -File |
    Where-Object {
        $_.Name -match '^rgl_log.*\.(txt|log)$' -and
        -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)
    } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 10)

if ($matchingFiles.Count -eq 0) {
    throw 'No rgl_log*.txt or rgl_log*.log files were found in the selected directory. Subdirectories are not searched. Specify the actual log folder with -LogDirectory.'
}

$selectedFiles = @($matchingFiles | Where-Object { $_.Length -le $maxFileBytes })
foreach ($largeFile in @($matchingFiles | Where-Object { $_.Length -gt $maxFileBytes })) {
    Write-Warning ("Skipped log larger than 20 MiB: {0}. Inspect it separately if needed." -f $largeFile.Name)
}
if ($selectedFiles.Count -eq 0) {
    throw 'All matching logs exceed 20 MiB. Inspect the newest error log manually; no archive was created.'
}

$resolvedOutput = [IO.Path]::GetFullPath($OutputPath)
if ([IO.Path]::GetExtension($resolvedOutput) -ne '.zip') {
    throw '-OutputPath must end in .zip.'
}
if (Test-Path -LiteralPath $resolvedOutput) {
    throw 'The output file already exists. Choose a new -OutputPath; existing files are never overwritten.'
}
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    throw 'The output directory does not exist. Choose an existing directory with -OutputPath.'
}

Write-Warning 'Logs may contain your Windows user name, personal paths, or other private text. Inspect the ZIP before sharing it. The script does not upload anything.'
$paths = @($selectedFiles | ForEach-Object { $_.FullName })
Compress-Archive -LiteralPath $paths -DestinationPath $resolvedOutput -CompressionLevel Optimal
Write-Host ("Created {0} from {1} text log(s)." -f $resolvedOutput, $selectedFiles.Count)
