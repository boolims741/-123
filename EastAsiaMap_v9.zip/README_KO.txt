# 설치와 실행 확인

이 파일은 v9 수정 후보의 설치 안내입니다. 게임 1.5.6은 사용자가 알려 준 버전이며, 실제 엔진에서의 로딩 성공과 다른 버전 호환성은 아직 확인하지 못했습니다.

## 1. 기존 시험본 보관

게임과 런처를 종료합니다. 기존 `Modules/EastAsiaMap_Trial` 폴더가 있으면 **Modules 바깥**에 옮겨 보관합니다. v7·v8을 다른 이름의 폴더로 바꿔 `Modules` 안에 남기거나 새 파일을 기존 폴더 위에 덮어쓰지 마세요. 같은 모듈 ID가 중복될 수 있습니다.

기존 저장 파일도 보관합니다. 이 단계에서 기존 게임 파일이나 저장 파일을 삭제할 필요는 없습니다.

## 2. 새 후보 설치

`EastAsiaMap_Trial_v9_candidate.zip`을 풀고, 안의 `EastAsiaMap_Trial` 폴더를 배너로드 설치 위치의 `Modules` 안에 넣습니다. 최종 구조는 다음과 같아야 합니다.

```text
Mount & Blade II Bannerlord/
└─ Modules/
   └─ EastAsiaMap_Trial/
      ├─ SubModule.xml
      ├─ ModuleData/
      │  └─ settlements.xml
      └─ SceneObj/
         └─ Main_map/
            ├─ scene.xscene
            ├─ terrain.bin
            ├─ navmesh.bin
            └─ ...
```

`Modules/EastAsiaMap_Trial/EastAsiaMap_Trial/SubModule.xml`처럼 폴더가 두 겹이면 설치 위치가 잘못된 것입니다. ZIP의 설명·검사 결과 파일을 `Modules`에 별도 모듈로 넣을 필요는 없습니다.

## 3. 런처와 새 캠페인

원본 모듈의 필수 의존성은 `Native`, `SandBoxCore`, `Sandbox`, `CustomBattle`, `StoryMode`, `NavalDLC`입니다. 해당 공식 모듈이 설치되어 있고, `EastAsiaMap_Trial`이 이들보다 뒤에서 로드되도록 설정합니다. `NavalDLC`가 없으면 이 패키지를 실행할 수 없습니다.

첫 확인에서는 다른 비공식 지도·캠페인 모드를 끄고, EastAsiaMap Trial 하나만 사용합니다. v7·v8이나 비교용 isolated 패키지와 함께 켜지 마세요.

**기존 저장을 불러오지 말고 새 샌드박스 캠페인**으로 확인합니다. 다음 항목을 순서대로 확인해 주세요.

1. 캐릭터 생성 후 캠페인 지도가 열리는지
2. 지형과 물이 보이며 정착지 아이콘이 나타나는지
3. 지도에서 부대를 이동시키고 가까운 정착지에 접근할 수 있는지
4. 새 슬롯에 저장한 뒤 그 저장을 다시 불러올 수 있는지

도시 이름·문화·세력이 칼라디아 그대로인 것은 현재 자료의 상태입니다. 한국·중국·일본 정착지 이름과 역사 세력을 적용한 완성본은 아닙니다. 항구 위치와 섬 사이 이동은 추가 검증이 필요합니다.

## 4. 다시 종료되면

실패한 단계, 오류창의 정확한 문구 또는 화면, 런처의 게임 버전과 활성 모듈 목록을 남겨 주세요. “게임을 시작하자마자”, “캐릭터 생성 후 지도 진입 중”, “지도는 열렸지만 이동 중”을 구분하면 원인 확인에 도움이 됩니다.

텍스트 로그가 필요하면 ZIP을 푼 폴더에서 Windows PowerShell로 선택적 수집 도구를 실행할 수 있습니다. 이 도구는 클라우드에서 실행 검증하지 못했습니다.

```powershell
powershell -NoProfile -File .\Collect-BannerlordCrash.ps1
```

기본 로그 폴더를 찾지 못하면 **실제로 로그가 있는 폴더**를 지정합니다.

```powershell
powershell -NoProfile -File .\Collect-BannerlordCrash.ps1 -LogDirectory 'D:\실제\로그폴더'
```

도구는 지정 폴더의 최신 `rgl_log*.txt`·`rgl_log*.log` 파일만 최대 10개 모읍니다. 파일당 20 MiB를 넘는 로그는 제외합니다. 로그에는 개인 경로가 포함될 수 있으므로 ZIP 내용을 확인한 뒤 공유해 주세요. 도구 실행이 안 되면 최신 오류 로그를 직접 전달해도 됩니다.

현재 후보는 정적 구조·좌표·패키징 검사 대상입니다. 실제 게임에서 충돌이 해결됐다는 보장은 없으며, 위 실행 결과가 다음 수정의 근거가 됩니다.
