EastAsiaMap v10.1 — Windows DLL 로드 호환 수정 후보

게임과 런처를 종료하고 ZIP을 새 폴더에 전부 풉니다.
압축을 푼 폴더의 EastAsiaMap_Install.exe를 실행합니다.
게임 경로를 자동으로 찾지 못하면 배너로드 설치 폴더를 선택하세요.
명령어 입력이나 별도 가입은 필요 없습니다.

설치 도구가 하는 일:
1. 배포된 지도 파일 9개의 SHA256을 확인합니다.
2. 검증된 자체 DLL 하나의 인터넷 파일 차단 표시를 제거합니다.
3. 실제 설치된 게임 DLL로 자체 DLL의 타입·의존성 로드를 먼저 검사합니다.
4. 검사에 통과하면 기존 EastAsiaMap_Trial 폴더 전체를 게임 설치 위치의
   EastAsiaMap_Backups 폴더에 보관한 뒤 새 모드를 설치합니다.
5. 파일 복사에 실패하면 기존 폴더를 복원합니다.

Native/NavalDLC 등 본체 DLL은 읽기만 하며 교체하지 않습니다.
로드 검사 실패 시 기존 모드 설치는 변경하지 않습니다.
실패 내용은 압축을 푼 폴더의 EastAsiaMap_install-check.log에 표시됩니다.
성공 시 기록은 Modules/EastAsiaMap_Trial/RuntimeDiagnostics/loader-check.log에 있습니다.

수정: 자체 DLL을 명시적인 .NET Framework 4.7.2 / x64로 빌드했습니다.
v10의 netstandard 의존성을 없애고 Windows 게임 쪽 참조 프로필을 사용합니다.
화면의 일반적인 Cannot load 메시지만으로 원인을 확정할 수는 없었습니다.
이 수정이 실제 Windows 로더 오류를 해결하는지는 아직 사용자 PC에서 미검증입니다.
설치 도구의 파일 백업/교체/실패 복원 검사는 9개 통과했습니다.
관리형 캐시 동작 검사 10개도 통과했습니다. Windows UI·NTFS·게임 실행 검사를
대신하는 결과는 아닙니다.

설치/로드 검사가 통과하면 새 샌드박스로 확인합니다. NavalDLC가 필요합니다.
현재 지도 거리 캐시 생성 때문에 첫 로딩이 길어질 수 있습니다.
게임 엔진에서 캠페인 진입 성공은 아직 검증하지 못했습니다.
캠페인 초기화 진단은 RuntimeDiagnostics/eastasia-runtime-실행번호.log에 남습니다.
